# Deployment Guide

## Quick Deployment

### Option 1: Netlify (Recommended)
1. **Build the project**
   ```bash
   npm run build
   ```

2. **Deploy to Netlify**
   - Drag and drop the `dist` folder to [Netlify Drop](https://app.netlify.com/drop)
   - Or connect your Git repository for automatic deployments

3. **Configure (Optional)**
   - Set up custom domain
   - Configure redirects for SPA routing

### Option 2: Vercel
1. **Connect Repository**
   - Import your project from GitHub/GitLab/Bitbucket
   - Vercel will auto-detect the Vite configuration

2. **Configure Build Settings**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

3. **Deploy**
   - Vercel will automatically build and deploy
   - Get your live URL instantly

### Option 3: GitHub Pages
1. **Install gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Add deploy script to package.json**
   ```json
   {
     "scripts": {
       "deploy": "gh-pages -d dist"
     }
   }
   ```

3. **Build and deploy**
   ```bash
   npm run build
   npm run deploy
   ```

## Advanced Deployment

### Environment Variables
Create a `.env` file for environment-specific settings:
```env
VITE_APP_TITLE=My Blog Platform
VITE_APP_DESCRIPTION=A beautiful markdown blog platform
VITE_API_URL=https://api.example.com
```

### Custom Domain Setup
1. **Add CNAME file** (for GitHub Pages)
   ```
   yourdomain.com
   ```

2. **Configure DNS**
   - Point your domain to your hosting provider
   - Set up SSL certificate

### Performance Optimization
1. **Enable Gzip Compression**
2. **Set up CDN**
3. **Configure Caching Headers**
4. **Optimize Images**

## Production Checklist

- [ ] Build passes without errors
- [ ] All features work in production build
- [ ] Responsive design tested on all devices
- [ ] Performance metrics are acceptable
- [ ] SEO meta tags are configured
- [ ] Analytics tracking is set up
- [ ] Error monitoring is configured
- [ ] Backup strategy is in place