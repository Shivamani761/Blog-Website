import React, { useState, useRef, useEffect } from 'react';
import { Save, Eye, Edit3, ArrowLeft, Trash2 } from 'lucide-react';
import { BlogPost } from '../types/blog';
import { renderMarkdown, extractExcerpt, extractTags } from '../utils/markdown';
import { useBlogStorage } from '../hooks/useBlogStorage';

interface BlogEditorProps {
  post?: BlogPost;
  onBack: () => void;
  onSave?: (post: BlogPost) => void;
}

export function BlogEditor({ post, onBack, onSave }: BlogEditorProps) {
  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const [isPreview, setIsPreview] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { savePost, updatePost, deletePost } = useBlogStorage();

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [content]);

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) return;

    setIsSaving(true);
    
    try {
      const excerpt = extractExcerpt(content);
      const tags = extractTags(content);
      
      let savedPost: BlogPost;
      
      if (post) {
        updatePost(post.id, { title, content, excerpt, tags });
        savedPost = { ...post, title, content, excerpt, tags };
      } else {
        savedPost = savePost({ title, content, excerpt, tags });
      }
      
      onSave?.(savedPost);
      
      // Show success feedback
      setTimeout(() => {
        setIsSaving(false);
      }, 500);
    } catch (error) {
      console.error('Error saving post:', error);
      setIsSaving(false);
    }
  };

  const handleDelete = () => {
    if (post && window.confirm('Are you sure you want to delete this post?')) {
      deletePost(post.id);
      onBack();
    }
  };

  const togglePreview = () => {
    setIsPreview(!isPreview);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft size={20} />
          Back to Blog
        </button>
        
        <div className="flex items-center gap-4">
          <button
            onClick={togglePreview}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              isPreview 
                ? 'bg-purple-100 text-purple-700' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {isPreview ? <Edit3 size={16} /> : <Eye size={16} />}
            {isPreview ? 'Edit' : 'Preview'}
          </button>
          
          {post && (
            <button
              onClick={handleDelete}
              className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
            >
              <Trash2 size={16} />
              Delete
            </button>
          )}
          
          <button
            onClick={handleSave}
            disabled={!title.trim() || !content.trim() || isSaving}
            className={`flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-colors ${
              isSaving
                ? 'bg-green-100 text-green-700'
                : 'bg-purple-600 text-white hover:bg-purple-700 disabled:opacity-50'
            }`}
          >
            <Save size={16} />
            {isSaving ? 'Saved!' : 'Save Post'}
          </button>
        </div>
      </div>

      {/* Title Input */}
      <div className="mb-6">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter your blog post title..."
          className="w-full text-4xl font-bold border-none outline-none bg-transparent placeholder-gray-300 focus:placeholder-gray-400"
        />
      </div>

      {/* Editor/Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 min-h-[500px]">
        {/* Editor */}
        <div className={`${isPreview ? 'hidden lg:block' : ''}`}>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
              <h3 className="font-medium text-gray-700">Markdown Editor</h3>
            </div>
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your blog post in Markdown..."
              className="w-full p-4 border-none outline-none resize-none font-mono text-sm leading-relaxed min-h-[450px]"
            />
          </div>
        </div>

        {/* Preview */}
        <div className={`${!isPreview ? 'hidden lg:block' : ''}`}>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
              <h3 className="font-medium text-gray-700">Preview</h3>
            </div>
            <div className="p-4 min-h-[450px]">
              {content ? (
                <div 
                  className="prose prose-lg max-w-none"
                  dangerouslySetInnerHTML={{ __html: renderMarkdown(content) }}
                />
              ) : (
                <p className="text-gray-400 italic">Your preview will appear here...</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}