import React from 'react';
import { ArrowLeft, Calendar, Tag, Edit } from 'lucide-react';
import { BlogPost } from '../types/blog';
import { renderMarkdown } from '../utils/markdown';

interface BlogViewerProps {
  post: BlogPost;
  onBack: () => void;
  onEdit: (post: BlogPost) => void;
}

export function BlogViewer({ post, onBack, onEdit }: BlogViewerProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          <ArrowLeft size={20} />
          Back to Blog
        </button>
        
        <button
          onClick={() => onEdit(post)}
          className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-medium"
        >
          <Edit size={16} />
          Edit Post
        </button>
      </div>

      {/* Post Content */}
      <article className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-8 lg:p-12">
          {/* Title */}
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
            {post.title}
          </h1>
          
          {/* Meta Information */}
          <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-8 pb-6 border-b border-gray-200">
            <div className="flex items-center gap-2">
              <Calendar size={16} />
              <span>Published {formatDate(post.createdAt)}</span>
            </div>
            
            {post.updatedAt !== post.createdAt && (
              <div className="flex items-center gap-2">
                <Edit size={16} />
                <span>Updated {formatDate(post.updatedAt)}</span>
              </div>
            )}
            
            {post.tags.length > 0 && (
              <div className="flex items-center gap-2">
                <Tag size={16} />
                <span>{post.tags.length} {post.tags.length === 1 ? 'tag' : 'tags'}</span>
              </div>
            )}
          </div>
          
          {/* Tags */}
          {post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-8">
              {post.tags.map(tag => (
                <span
                  key={tag}
                  className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
          
          {/* Content */}
          <div 
            className="prose prose-lg max-w-none prose-headings:text-gray-900 prose-a:text-purple-600 prose-a:no-underline hover:prose-a:underline prose-code:bg-gray-100 prose-code:px-1 prose-code:py-0.5 prose-code:rounded prose-pre:bg-gray-50 prose-pre:border"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
          />
        </div>
      </article>
    </div>
  );
}