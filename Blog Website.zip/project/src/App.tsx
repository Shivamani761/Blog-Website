import React, { useState } from 'react';
import { BlogList } from './components/BlogList';
import { BlogEditor } from './components/BlogEditor';
import { BlogViewer } from './components/BlogViewer';
import { BlogPost } from './types/blog';

type View = 'list' | 'editor' | 'viewer';

function App() {
  const [currentView, setCurrentView] = useState<View>('list');
  const [currentPost, setCurrentPost] = useState<BlogPost | null>(null);

  const handleNewPost = () => {
    setCurrentPost(null);
    setCurrentView('editor');
  };

  const handleEditPost = (post: BlogPost) => {
    setCurrentPost(post);
    setCurrentView('editor');
  };

  const handleViewPost = (post: BlogPost) => {
    setCurrentPost(post);
    setCurrentView('viewer');
  };

  const handleBackToList = () => {
    setCurrentPost(null);
    setCurrentView('list');
  };

  const handlePostSaved = (post: BlogPost) => {
    setCurrentPost(post);
    // Stay in editor view after saving
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentView === 'list' && (
        <BlogList
          onNewPost={handleNewPost}
          onEditPost={handleEditPost}
          onViewPost={handleViewPost}
        />
      )}
      
      {currentView === 'editor' && (
        <BlogEditor
          post={currentPost || undefined}
          onBack={handleBackToList}
          onSave={handlePostSaved}
        />
      )}
      
      {currentView === 'viewer' && currentPost && (
        <BlogViewer
          post={currentPost}
          onBack={handleBackToList}
          onEdit={handleEditPost}
        />
      )}
    </div>
  );
}

export default App;