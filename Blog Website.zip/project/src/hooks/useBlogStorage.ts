import { useState, useEffect } from 'react';
import { BlogPost, BlogStorage } from '../types/blog';

const STORAGE_KEY = 'markdown-blog-posts';

export function useBlogStorage() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  // Load posts from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data: BlogStorage = JSON.parse(stored);
        setPosts(data.posts || []);
      }
    } catch (error) {
      console.error('Error loading blog posts:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Save posts to localStorage whenever posts change
  useEffect(() => {
    if (!loading) {
      try {
        const data: BlogStorage = { posts };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      } catch (error) {
        console.error('Error saving blog posts:', error);
      }
    }
  }, [posts, loading]);

  const savePost = (post: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newPost: BlogPost = {
      ...post,
      id: Date.now().toString(),
      createdAt: now,
      updatedAt: now,
    };
    setPosts(prev => [newPost, ...prev]);
    return newPost;
  };

  const updatePost = (id: string, updates: Partial<BlogPost>) => {
    setPosts(prev => 
      prev.map(post => 
        post.id === id 
          ? { ...post, ...updates, updatedAt: new Date().toISOString() }
          : post
      )
    );
  };

  const deletePost = (id: string) => {
    setPosts(prev => prev.filter(post => post.id !== id));
  };

  const getPost = (id: string): BlogPost | undefined => {
    return posts.find(post => post.id === id);
  };

  return {
    posts,
    loading,
    savePost,
    updatePost,
    deletePost,
    getPost,
  };
}